%% #1
close all; clear; clc
load Fitting.mat;

Y=log(y);
A=[-t ones(length(t),1)];
Xopt=inv(A'*A)*A'*Y;
a=Xopt(1);
y0=exp(Xopt(2));

yest=y0*exp(-a*t);
plot(t,y);
hold on; grid on;
plot(t,yest,'LineWidth',3);
xlabel('Time(s)');
ylabel('y(t)');
legend('y(t) = y(0)*e^-^a^t + noise','yest');
%% #2
close all; clear; clc
load Line3D.mat;
Ay = [ones(length(x),1) x x.^2];
Yopt = inv(Ay'*Ay)*Ay'*y;
Yest = Ay*Yopt;
Az = [x Yest];
Zopt = inv(Az'*Az)*Az'*z;
Zest = Az*Zopt;

figure
plot3(x,y,z,'o')
grid on; hold on;
plot3(x,Yest,Zest,'LineWidth',2)
legend('Data Points','Fitting Result');
xlabel('x'); ylabel('y'); zlabel('z');
%% #3
close all;clear;clc
load Sin_Cos_Data.mat;
A1 = [sin(3.5*t) cos(3.5*t)];
Y1_opt = inv(A1'*A1)*A1'*y1_noise;
Y1_est = A1*Y1_opt;
plot(t,y1_noise);
grid on; hold on;
plot(t,Y1_est,'LineWidth',2);
xlabel('Time(s)');
ylabel('Response of y1');
legend('y1_ noise','fitting result');
A2=[cos(5.2*t) sin(5.2*t)];
Y2_opt = inv(A2'*A2)*A2'*y2_noise;
Y2_est = A2*Y2_opt;
figure
plot(t,y2_noise);
grid on; hold on;
plot(t,Y2_est,'LineWidth',2);
xlabel('Time(s)');
ylabel('Response of y2');
legend('y2_ noise','fitting result');

syms a1 p1;
[Sa1,Sp1] = solve(a1*cos(p1)==1.4027, a1*sin(p1)==2.3964);
syms a2 p2;
[Sa2,Sp2] = solve(a2*cos(p2)==2.7763, -a2*sin(p2)==-1.5928);

noise = y1_noise-Y1_est;
s=std(noise)
m=mean(noise)
figure
plot(t,noise);
figure
hist(noise,100) %WhiteGuassianNoise
hold on;
xline(m,'r--','mean');
xline(m+s,'g--','first s');
xline(m-s,'g--','first s');
title('estimated noise hist')
%% #4
close all;clear;clc
load Plane3D_Data.mat;
X=reshape(x,[],1);
Y=reshape(y,[],1);
Z=reshape(z_noise,[],1);
A=[X.^2 Y.^2 X.^2.*abs(Y) ones(length(X),1)];
Zopt=inv(A'*A)*A'*Z;
Zest=Zopt(1)*x.^2+Zopt(2)*y.^2+Zopt(3)*x.^2.*abs(y)+Zopt(4);

W=var(Z.^(-1));
Zopt_w=inv(A'*W'*A)*A'*W*Z;
Zest_w=Zopt_w(1)*x.^2+Zopt_w(2)*y.^2+Zopt_w(3)*x.^2.*abs(y)+Zopt_w(4);

plot3(x,y,z_noise,'b.');
grid on;hold on;
plot3(x,y,Zest,'r-');
plot3(x,y,Zest_w,'g.','LineWidth',1);
