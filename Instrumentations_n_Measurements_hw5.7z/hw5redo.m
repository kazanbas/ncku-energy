%% 5-3 Sinewave subject to a white noise. Analyze the std of the noise. 
clear;clc;clear all
load Signal_Noise_Analysis.mat
uin=ynoise; dT=0.001; f=1;
p=1/(1+2*pi*f*dT);
for n=1:length(t)
    if n==1
        uout(n)=(1-pi)*uin(n);
    else
        uout(n)=p*uout(n-1)+(1-p)*uin(n);
    end
end
noise=uin-uout'; %'(prime)
std_og_sig=std(t)
std_sig=std(uout)
std_noise=std(noise)

figure
plot(t,ynoise)
ylabel('Signal')
figure
subplot(2,1,1)
plot(t,uout);
hold on
axis([0 4 -2 2])
ylabel('Signal (w/o noise)');
subplot(2,1,2)
plot(t,noise);
axis([0 4 -2 2]);
xlabel('Time(s)')
ylabel('Noise')

%% 5-4 System subject to a periodic impact force.
% Design an analysis method to estimate the period (T) of the impact force.
clear;clc;close all
load Signal_Impact.mat
dT=0.0001; f=0.5;
p=1/(1+2*pi*f*dT);
uin=y;
for n=1:length(time)
    if n==1
        uout(n)=(1-p)*uin(n);
    else
        uout(n)=p*uout(n-1)+(1-p)*uin(n);
    end
end
figure
subplot(2,1,1)
plot(time,y)
axis([0 20 -5 5]);
ylabel('Signal')
subplot(2,1,2)
plot(time,uout);
axis([0 20 -5 5]);
xlabel('Time(s)')
ylabel('Signal(no impact force)') 

%% 6
% A 2nd order filter(NTF) is with the form
% G(s)=(s^2+wc^2)/(s^2+2*xi*s+wc^2)
% For the given signal
% y(t)=sin(2*pi*f1*t)+cos(2*pi*f2*t)
% f1=1; f2=30
% Realize the NTF under the sampling period T=0.01(sec) to remove "f2" from
% y(t), where the bandwidth of the NTF is 10Hz.
% A) Show the filtering result w/o  the use of f-pre-warping.
% B) Show the filtering result with the use of f-pre-warping.
% C) Draw the bode plot for the NTF with/without f-pre-warping.
% D) What is the realized center f in descrete time domain if the
% f-pre-warping is NOT applied.
% E) Is the f-pre-warping necessary, give you observation.
%% notch filter
T=0.01;
t=0:T:3;
fc=30;
wc=2*pi*fc;
wb=2*pi*10;
e=1/2*(wb/wc);
uin=sin(2*pi*1*t)+sin(2*pi*30*t);

B0=1;
B1=0;
B2=wc^2;
A0=1;
A1=2*e*wc;
A2=wc^2;
%% 2nd order standard filter
A0D=A0*(2/T)^2+A1*(2/T)+A2;
A1D=-2*A0*(2/T)^2+2*A2;
A2D=A0*(2/T)^2-A1*(2/T)+A2;
B0D=B0*(2/T)^2+B1*(2/T)+B2;
B1D=-2*B0*(2/T)^2+2*B2;
B2D=B0*(2/T)^2-B1*(2/T)+B2;

for k=1:length(t)
    if k==1
        uout(k)=1/A0D*(B0D*uin(k));
    elseif k==2
        uout(k)=1/A0D*(-A1D*uout(k-1)+B0D*uin(k)+B1D*uin(k-1));
    else
        uout(k)=1/A0D*(-A1D*uout(k-1)-A2D*uout(k-2)+B0D*uin(k)+B1D*uin(k-1)+B2D*uin(k-2));
    end
end
%% frequency pre warping
fp=wc/(tan(wc*T/2));
A0D2=A0*(fp)^2+A1*(fp)+A2;
A1D2=-2*A0*(fp)^2+2*A2;
A2D2=A0*(fp)^2-A1*(fp)+A2;
B0D2=A0*(fp)^2+B1*(fp)+B2;
B1D2=-2*B0*(fp)^2+2*B2;
B2D2=B0*(fp)^2-B1*(fp)+B2;

for k=1:length(t)
    if k==1
        uout2(k)=1/A0D2*(B0D2*uin(k));
    elseif k==2
        uout2(k)=1/A0D2*(-A1D2*uout2(k-1)+B0D2*uin(k)+B1D2*uin(k-1));
    else
        uout2(k)=1/A0D2*(-A1D2*uout2(k-1)-A2D2*uout2(k-2)+B0D2*uin(k)+B1D2*uin(k-1)+B2D2*uin(k-2));
    end
end

subplot(3,1,1)
plot(uin);
ylabel('1 Hz+30 Hz');
subplot(3,1,2)
plot(uout);
ylabel('filter without FP');
subplot(3,1,3)
plot(uout2);
ylabel('filter with FP');
xlabel('time(s)');

figure
hold 
plot(uin);
plot(uout);
plot(uout2,'r','LineWidth',1);
xlabel('time(s)');
ylabel('filtering comparison');
legend('signal','NTF without FP','NTP with FP');
hold off
%% bode plot
% numerator
num=[1 0 wc^2]
%denominator
den=[1 2*e*wc wc^2]
%transfer function
G=tf(num,den)
%% prewarping bode plot
FP=[fp^2, fp, 1;-2*fp^2,0,2;fp^2,-fp,1;]
AD2_matrix=[A0D2;A1D2;A2D2;]
A2_matrix=(FP^-1)*AD2_matrix

BD2_matrix=[B0D2;B1D2;B2D2;]
B2_matrix=(FP^-1)*BD2_matrix

num2=[0.0001 0 3.5531]
den2=[0.0001 0.0063 3.5531]
G2=tf(num2,den2)

%plot frequency response
figure
bode(G,'b')
figure
bode(G2)
hold off
       