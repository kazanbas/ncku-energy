%3
clear;clc;close all;
load Signal_Noise_Analysis.mat

u_in = ynoise;
dT = 0.001;
freq = 1;
p = 1/(1+2*pi*freq*dT);
for n = 1:length(t)
    if n == 1
        u_out(n) = (1-p)*u_in(n);
    else
        u_out(n) = p*u_out(n-1)+(1-p)*u_in(n);
    end
end
noise=u_in-u_out';
std_og_sig=std(t)
std_sig=std(u_out)
std_noise=std(noise)

%plot(std_og,std_noise)

%%
%4
close all; clear; clc
load Signal_Impact.mat

T= 0.001*1/length(time);
%f=10000;
f=100000;
A1=1/(2*pi*f);
B1=1/(2*pi*f);
A2=1;
B2=0;
A1D=2*A1+A2*T;
A2D=A2*T-2*A1;
B1D=2*B1+B2*T;
B2D=B2*T-2*B1;
u_in=y;
for k=1:length(time)
if k==1
u_out(k)=1/A1D*(B1D*u_in(k));
else
u_out(k)=1/A1D*(-A2D*u_out(k-1)+B1D*u_in(k)+B2D*u_in(k-1));
end
end
figure
hold on
plot(time,u_out)
xlabel('Time(sex)')
ylabel('Signal Response')
figure
plot(time,u_out>1)